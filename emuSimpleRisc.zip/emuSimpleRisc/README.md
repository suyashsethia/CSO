EmuSr
=====

Java Based Emulator for Simple Risc Assembly Language
This is a Java Based Emulator For Simple Assembly Language 
#Find TestCases in Folder named TestCases run them have fun!!

 
