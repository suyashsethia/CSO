/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package backend;

/**
 *
 * @author ROCK
 */
public class NFlagRegister
{

    public static int GT;
    public static int E;

    public NFlagRegister()
      {
        GT = 0;
        E = 0;

      }
}
